using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aplicativo_ListaDeDesejos;

public partial class Editar_Perfil : ContentPage
{
    public Editar_Perfil()
    {
        InitializeComponent();
    }
}
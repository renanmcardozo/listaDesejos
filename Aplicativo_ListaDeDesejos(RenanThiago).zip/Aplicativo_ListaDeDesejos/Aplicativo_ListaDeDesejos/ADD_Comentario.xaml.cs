using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aplicativo_ListaDeDesejos;

public partial class ADD_Comentario : ContentPage
{
    public ADD_Comentario()
    {
        InitializeComponent();
    }
}